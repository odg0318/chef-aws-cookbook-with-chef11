module Aws
  module Service
  end
end
