Aws.add_service(:IoTDataPlane, {
  api: "#{Aws::API_DIR}/iot-data/2015-05-28/api-2.json",
  docs: "#{Aws::API_DIR}/iot-data/2015-05-28/docs-2.json",
})
