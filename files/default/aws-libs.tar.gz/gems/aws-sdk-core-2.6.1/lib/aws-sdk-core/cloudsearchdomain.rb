Aws.add_service(:CloudSearchDomain, {
  api: "#{Aws::API_DIR}/cloudsearchdomain/2013-01-01/api-2.json",
  docs: "#{Aws::API_DIR}/cloudsearchdomain/2013-01-01/docs-2.json",
  examples: "#{Aws::API_DIR}/cloudsearchdomain/2013-01-01/examples-1.json",
})
