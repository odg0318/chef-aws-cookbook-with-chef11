module Aws
  EmptyStructure = Class.new(Structure.new('AwsEmptyStructure'))
end
