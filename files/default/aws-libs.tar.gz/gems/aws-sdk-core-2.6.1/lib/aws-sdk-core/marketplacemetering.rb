Aws.add_service(:MarketplaceMetering, {
  api: "#{Aws::API_DIR}/meteringmarketplace/2016-01-14/api-2.json",
  docs: "#{Aws::API_DIR}/meteringmarketplace/2016-01-14/docs-2.json",
  examples: "#{Aws::API_DIR}/meteringmarketplace/2016-01-14/examples-1.json",
})
