Aws.add_service(:SWF, {
  api: "#{Aws::API_DIR}/swf/2012-01-25/api-2.json",
  docs: "#{Aws::API_DIR}/swf/2012-01-25/docs-2.json",
  paginators: "#{Aws::API_DIR}/swf/2012-01-25/paginators-1.json",
})
