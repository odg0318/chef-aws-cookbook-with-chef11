module Aws
  VERSION = '2.6.1'
end
