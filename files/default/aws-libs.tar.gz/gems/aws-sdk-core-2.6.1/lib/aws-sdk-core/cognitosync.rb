Aws.add_service(:CognitoSync, {
  api: "#{Aws::API_DIR}/cognito-sync/2014-06-30/api-2.json",
  docs: "#{Aws::API_DIR}/cognito-sync/2014-06-30/docs-2.json",
})
