module JMESPath
  VERSION = '1.3.1'
end
